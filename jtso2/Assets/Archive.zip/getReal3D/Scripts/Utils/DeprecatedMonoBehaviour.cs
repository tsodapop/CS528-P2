﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace getReal3D
{
    public class DeprecatedMonoBehaviour : MonoBehaviour { }

    public class DeprecatedGetRealUserScript : getRealUserScript { }
}
