﻿public class TestSyncListUInt : TestSyncListBase<uint> {
}
