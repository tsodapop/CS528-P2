﻿public class TestSyncListInt : TestSyncListBase<int> {
}
