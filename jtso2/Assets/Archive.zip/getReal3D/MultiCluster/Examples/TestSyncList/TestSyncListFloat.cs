﻿public class TestSyncListFloat : TestSyncListBase<float> {
}
