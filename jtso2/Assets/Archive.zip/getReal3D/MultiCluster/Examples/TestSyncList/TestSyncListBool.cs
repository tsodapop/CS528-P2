﻿public class TestSyncListBool : TestSyncListBase<bool> {
}
