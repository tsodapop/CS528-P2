﻿using UnityEngine;

public class TestSyncListVector3 : TestSyncListBase<Vector3> {

}
