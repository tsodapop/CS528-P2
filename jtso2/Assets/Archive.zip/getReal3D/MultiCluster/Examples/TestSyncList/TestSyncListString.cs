﻿public class TestSyncListString : TestSyncListBase<string> {
}
